#ifdef __CLING__
#pragma cling optimize(0)
#endif
void nlojet_comp_3020_5020gev()
{
//=========Macro generated from canvas: cPub/cPub
//=========  (Tue Dec 19 13:04:40 2023) by ROOT version 6.28/04
   TCanvas *cPub = new TCanvas("cPub", "cPub",0,67,1500,300);
   gStyle->SetOptStat(0);
   gStyle->SetOptTitle(0);
   cPub->Range(0,0,1,1);
   cPub->SetFillColor(0);
   cPub->SetBorderMode(0);
   cPub->SetBorderSize(2);
   cPub->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: cPub_1
   TPad *cPub_1 = new TPad("cPub_1", "cPub_1",0.01,0.01,0.19,0.99);
   cPub_1->Draw();
   cPub_1->cd();
   cPub_1->Range(-4.176119,-0.07643368,3.273958,0.4331241);
   cPub_1->SetFillColor(0);
   cPub_1->SetBorderMode(0);
   cPub_1->SetBorderSize(2);
   cPub_1->SetLeftMargin(0.15);
   cPub_1->SetRightMargin(0.01);
   cPub_1->SetTopMargin(0.04);
   cPub_1->SetBottomMargin(0.15);
   cPub_1->SetFrameBorderMode(0);
   cPub_1->SetFrameBorderMode(0);
   
   TMultiGraph *multigraph = new TMultiGraph();
   multigraph->SetName("");
   multigraph->SetTitle("");
   
   Double_t gr_pub_55_75_fx1[18] = { -2.77415, -2.35165, -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085, 1.7325, 2.155,
   2.71835 };
   Double_t gr_pub_55_75_fy1[18] = { 0.001096712, 0.01851103, 0.06135381, 0.1033289, 0.1511131, 0.1993502, 0.2432752, 0.2838158, 0.3174255, 0.3389175, 0.3503245, 0.3498483, 0.3314536, 0.301076, 0.2578431, 0.2063402, 0.1191301,
   0.02725358 };
   TGraph *graph = new TGraph(18,gr_pub_55_75_fx1,gr_pub_55_75_fy1);
   graph->SetName("gr_pub_55_75");
   graph->SetTitle("pub_55_75_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(2);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(2);
   graph->SetMarkerStyle(20);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_gr_pub_55_751 = new TH1F("Graph_gr_pub_55_751","pub_55_75_5020gev.txt",100,-3.3234,3.2676);
   Graph_gr_pub_55_751->SetMinimum(0.0009870404);
   Graph_gr_pub_55_751->SetMaximum(0.3852473);
   Graph_gr_pub_55_751->SetDirectory(nullptr);
   Graph_gr_pub_55_751->SetStats(0);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#000099");
   Graph_gr_pub_55_751->SetLineColor(ci);
   Graph_gr_pub_55_751->GetXaxis()->SetLabelFont(42);
   Graph_gr_pub_55_751->GetXaxis()->SetTitleOffset(1);
   Graph_gr_pub_55_751->GetXaxis()->SetTitleFont(42);
   Graph_gr_pub_55_751->GetYaxis()->SetLabelFont(42);
   Graph_gr_pub_55_751->GetYaxis()->SetTitleFont(42);
   Graph_gr_pub_55_751->GetZaxis()->SetLabelFont(42);
   Graph_gr_pub_55_751->GetZaxis()->SetTitleOffset(1);
   Graph_gr_pub_55_751->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_gr_pub_55_751);
   
   multigraph->Add(graph,"");
   
   Double_t gr_rep_55_75_fx2[50] = { -1.985, -1.885, -1.785, -1.685, -1.585, -1.485, -1.385, -1.285, -1.185, -1.085, -0.985, -0.885, -0.785, -0.685, -0.585, -0.485, -0.385,
   -0.285, -0.185, -0.085, 0.015, 0.115, 0.215, 0.315, 0.415, 0.515, 0.615, 0.715, 0.815, 0.915, 1.015, 1.115, 1.215,
   1.315, 1.415, 1.515, 1.615, 1.715, 1.815, 1.915, 2.015, 2.115, 2.215, 2.315, 2.415, 2.515, 2.615, 2.715, 2.815,
   2.915 };
   Double_t gr_rep_55_75_fy2[50] = { 0.02972212, 0.03564026, 0.05755846, 0.08324875, 0.1035654, 0.1142615, 0.1458992, 0.1563532, 0.1560761, 0.1880419, 0.1802182, 0.2368998, 0.2704131, 0.2603388, 0.2563997, 0.2999555, 0.3247712,
   0.3369679, 0.3403291, 0.3574516, 0.3457682, 0.3543503, 0.379791, 0.3759234, 0.3931397, 0.3787713, 0.3674499, 0.3695248, 0.3564326, 0.3347052, 0.3622656, 0.3524425, 0.3260852,
   0.3038297, 0.2995765, 0.2491317, 0.2291069, 0.231271, 0.2242568, 0.2013958, 0.1888354, 0.1415747, 0.1313861, 0.1075538, 0.1019073, 0.08924819, 0.08980475, 0.05500651, 0.0427864,
   0.0239325 };
   graph = new TGraph(50,gr_rep_55_75_fx2,gr_rep_55_75_fy2);
   graph->SetName("gr_rep_55_75");
   graph->SetTitle("rep3020_55_75_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(4);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(4);
   graph->SetMarkerStyle(24);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_gr_rep_55_752 = new TH1F("Graph_gr_rep_55_752","rep3020_55_75_5020gev.txt",100,-2.475,3.405);
   Graph_gr_rep_55_752->SetMinimum(0.02153925);
   Graph_gr_rep_55_752->SetMaximum(0.4300604);
   Graph_gr_rep_55_752->SetDirectory(nullptr);
   Graph_gr_rep_55_752->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_gr_rep_55_752->SetLineColor(ci);
   Graph_gr_rep_55_752->GetXaxis()->SetLabelFont(42);
   Graph_gr_rep_55_752->GetXaxis()->SetTitleOffset(1);
   Graph_gr_rep_55_752->GetXaxis()->SetTitleFont(42);
   Graph_gr_rep_55_752->GetYaxis()->SetLabelFont(42);
   Graph_gr_rep_55_752->GetYaxis()->SetTitleFont(42);
   Graph_gr_rep_55_752->GetZaxis()->SetLabelFont(42);
   Graph_gr_rep_55_752->GetZaxis()->SetTitleOffset(1);
   Graph_gr_rep_55_752->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_gr_rep_55_752);
   
   multigraph->Add(graph,"");
   multigraph->Draw("AP");
   multigraph->GetXaxis()->SetLimits(-3.058607, 3.199457);
   multigraph->GetXaxis()->SetTitle("#eta_{dijet}");
   multigraph->GetXaxis()->SetLabelFont(42);
   multigraph->GetXaxis()->SetTitleSize(0.05);
   multigraph->GetXaxis()->SetTitleOffset(1);
   multigraph->GetXaxis()->SetTitleFont(42);
   multigraph->GetYaxis()->SetTitle("d^{2}#sigma / dp_{T}^{ave}d#eta_{dijet}");
   multigraph->GetYaxis()->SetLabelFont(42);
   multigraph->GetYaxis()->SetTitleSize(0.05);
   multigraph->GetYaxis()->SetTitleFont(42);
   TLatex *   tex = new TLatex(0.18,0.92,"NLOJet++ pPb #sqrt{s_{NN}}=5020 GeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
      tex = new TLatex(0.18,0.87,"55 < p_{T}^{ave} < 75 GeV/c");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
   cPub_1->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_2
   TPad *cPub_2 = new TPad("cPub_2", "cPub_2",0.21,0.01,0.39,0.99);
   cPub_2->Draw();
   cPub_2->cd();
   cPub_2->Range(-3.649503,-0.07435589,3.247301,0.42135);
   cPub_2->SetFillColor(0);
   cPub_2->SetBorderMode(0);
   cPub_2->SetBorderSize(2);
   cPub_2->SetLeftMargin(0.15);
   cPub_2->SetRightMargin(0.01);
   cPub_2->SetTopMargin(0.04);
   cPub_2->SetBottomMargin(0.15);
   cPub_2->SetFrameBorderMode(0);
   cPub_2->SetFrameBorderMode(0);
   
   multigraph = new TMultiGraph();
   multigraph->SetName("");
   multigraph->SetTitle("");
   
   Double_t Graph_fx3[17] = { -2.35165, -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085, 1.7325, 2.155, 2.71835 };
   Double_t Graph_fy3[17] = { 0.008056904, 0.04029148, 0.08253176, 0.1341185, 0.1902633, 0.2405449, 0.2890796, 0.3278334, 0.3527867, 0.3680392, 0.3661056, 0.3475721, 0.3151789, 0.2691118, 0.2120753, 0.1183062, 0.02361223 };
   graph = new TGraph(17,Graph_fx3,Graph_fy3);
   graph->SetName("Graph");
   graph->SetTitle("pub_75_95_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(2);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(2);
   graph->SetMarkerStyle(20);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_Graph3 = new TH1F("Graph_Graph3","pub_75_95_5020gev.txt",100,-2.85865,3.22535);
   Graph_Graph3->SetMinimum(0.007251213);
   Graph_Graph3->SetMaximum(0.4040374);
   Graph_Graph3->SetDirectory(nullptr);
   Graph_Graph3->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_Graph3->SetLineColor(ci);
   Graph_Graph3->GetXaxis()->SetLabelFont(42);
   Graph_Graph3->GetXaxis()->SetTitleOffset(1);
   Graph_Graph3->GetXaxis()->SetTitleFont(42);
   Graph_Graph3->GetYaxis()->SetLabelFont(42);
   Graph_Graph3->GetYaxis()->SetTitleFont(42);
   Graph_Graph3->GetZaxis()->SetLabelFont(42);
   Graph_Graph3->GetZaxis()->SetTitleOffset(1);
   Graph_Graph3->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_Graph3);
   
   multigraph->Add(graph,"");
   
   Double_t gr_rep_75_95_fx4[50] = { -1.985, -1.885, -1.785, -1.685, -1.585, -1.485, -1.385, -1.285, -1.185, -1.085, -0.985, -0.885, -0.785, -0.685, -0.585, -0.485, -0.385,
   -0.285, -0.185, -0.085, 0.015, 0.115, 0.215, 0.315, 0.415, 0.515, 0.615, 0.715, 0.815, 0.915, 1.015, 1.115, 1.215,
   1.315, 1.415, 1.515, 1.615, 1.715, 1.815, 1.915, 2.015, 2.115, 2.215, 2.315, 2.415, 2.515, 2.615, 2.715, 2.815,
   2.915 };
   Double_t gr_rep_75_95_fy4[50] = { 0.0147804, 0.03219029, 0.05012626, 0.06522764, 0.06370477, 0.09812127, 0.1196313, 0.1129173, 0.1434146, 0.1548573, 0.1790671, 0.2096256, 0.2466958, 0.2567391, 0.2731165, 0.2833138, 0.2948028,
   0.3199116, 0.3395613, 0.3473181, 0.3633039, 0.3674558, 0.3816023, 0.3744022, 0.3827854, 0.3824287, 0.3766919, 0.3812109, 0.3779849, 0.3601381, 0.3528351, 0.3482082, 0.3169561,
   0.3043568, 0.2925533, 0.2731228, 0.2553171, 0.2290984, 0.2039119, 0.1928937, 0.180354, 0.1537116, 0.1216391, 0.1173937, 0.09389865, 0.07200493, 0.05830985, 0.04948632, 0.04617608,
   0.02691019 };
   graph = new TGraph(50,gr_rep_75_95_fx4,gr_rep_75_95_fy4);
   graph->SetName("gr_rep_75_95");
   graph->SetTitle("rep3020_75_95_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(4);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(4);
   graph->SetMarkerStyle(24);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_gr_rep_75_954 = new TH1F("Graph_gr_rep_75_954","rep3020_75_95_5020gev.txt",100,-2.475,3.405);
   Graph_gr_rep_75_954->SetMinimum(0.01330236);
   Graph_gr_rep_75_954->SetMaximum(0.4195859);
   Graph_gr_rep_75_954->SetDirectory(nullptr);
   Graph_gr_rep_75_954->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_gr_rep_75_954->SetLineColor(ci);
   Graph_gr_rep_75_954->GetXaxis()->SetLabelFont(42);
   Graph_gr_rep_75_954->GetXaxis()->SetTitleOffset(1);
   Graph_gr_rep_75_954->GetXaxis()->SetTitleFont(42);
   Graph_gr_rep_75_954->GetYaxis()->SetLabelFont(42);
   Graph_gr_rep_75_954->GetYaxis()->SetTitleFont(42);
   Graph_gr_rep_75_954->GetZaxis()->SetLabelFont(42);
   Graph_gr_rep_75_954->GetZaxis()->SetTitleOffset(1);
   Graph_gr_rep_75_954->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_gr_rep_75_954);
   
   multigraph->Add(graph,"");
   multigraph->Draw("AP");
   multigraph->GetXaxis()->SetLimits(-2.614982, 3.178333);
   multigraph->GetXaxis()->SetTitle("#eta_{dijet}");
   multigraph->GetXaxis()->SetLabelFont(42);
   multigraph->GetXaxis()->SetTitleSize(0.05);
   multigraph->GetXaxis()->SetTitleOffset(1);
   multigraph->GetXaxis()->SetTitleFont(42);
   multigraph->GetYaxis()->SetTitle("d^{2}#sigma / dp_{T}^{ave}d#eta_{dijet}");
   multigraph->GetYaxis()->SetLabelFont(42);
   multigraph->GetYaxis()->SetTitleSize(0.05);
   multigraph->GetYaxis()->SetTitleFont(42);
      tex = new TLatex(0.18,0.87,"75 < p_{T}^{ave} < 95 GeV/c");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
   cPub_2->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_3
   TPad *cPub_3 = new TPad("cPub_3", "cPub_3",0.41,0.01,0.59,0.99);
   cPub_3->Draw();
   cPub_3->cd();
   cPub_3->Range(-3.649503,-0.07672033,3.247301,0.4347485);
   cPub_3->SetFillColor(0);
   cPub_3->SetBorderMode(0);
   cPub_3->SetBorderSize(2);
   cPub_3->SetLeftMargin(0.15);
   cPub_3->SetRightMargin(0.01);
   cPub_3->SetTopMargin(0.04);
   cPub_3->SetBottomMargin(0.15);
   cPub_3->SetFrameBorderMode(0);
   cPub_3->SetFrameBorderMode(0);
   
   multigraph = new TMultiGraph();
   multigraph->SetName("");
   multigraph->SetTitle("");
   
   Double_t Graph_fx5[17] = { -2.35165, -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085, 1.7325, 2.155, 2.71835 };
   Double_t Graph_fy5[17] = { 0.002600559, 0.0225542, 0.05955763, 0.1118572, 0.1714378, 0.2313938, 0.2851709, 0.3282355, 0.3590886, 0.374227, 0.3740803, 0.3538156, 0.3190078, 0.270303, 0.2093777, 0.1102455, 0.01865911 };
   graph = new TGraph(17,Graph_fx5,Graph_fy5);
   graph->SetName("Graph");
   graph->SetTitle("pub_95_115_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(2);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(2);
   graph->SetMarkerStyle(20);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_Graph5 = new TH1F("Graph_Graph5","pub_95_115_5020gev.txt",100,-2.85865,3.22535);
   Graph_Graph5->SetMinimum(0.002340503);
   Graph_Graph5->SetMaximum(0.4113897);
   Graph_Graph5->SetDirectory(nullptr);
   Graph_Graph5->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_Graph5->SetLineColor(ci);
   Graph_Graph5->GetXaxis()->SetLabelFont(42);
   Graph_Graph5->GetXaxis()->SetTitleOffset(1);
   Graph_Graph5->GetXaxis()->SetTitleFont(42);
   Graph_Graph5->GetYaxis()->SetLabelFont(42);
   Graph_Graph5->GetYaxis()->SetTitleFont(42);
   Graph_Graph5->GetZaxis()->SetLabelFont(42);
   Graph_Graph5->GetZaxis()->SetTitleOffset(1);
   Graph_Graph5->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_Graph5);
   
   multigraph->Add(graph,"");
   
   Double_t gr_rep_95_115_fx6[50] = { -1.985, -1.885, -1.785, -1.685, -1.585, -1.485, -1.385, -1.285, -1.185, -1.085, -0.985, -0.885, -0.785, -0.685, -0.585, -0.485, -0.385,
   -0.285, -0.185, -0.085, 0.015, 0.115, 0.215, 0.315, 0.415, 0.515, 0.615, 0.715, 0.815, 0.915, 1.015, 1.115, 1.215,
   1.315, 1.415, 1.515, 1.615, 1.715, 1.815, 1.915, 2.015, 2.115, 2.215, 2.315, 2.415, 2.515, 2.615, 2.715, 2.815,
   2.915 };
   Double_t gr_rep_95_115_fy6[50] = { 0.02246388, 0.0209174, 0.03521315, 0.0480841, 0.06792369, 0.09304108, 0.1079889, 0.117008, 0.1523141, 0.1788545, 0.1950975, 0.2049556, 0.2277779, 0.2536476, 0.2692587, 0.2951205, 0.3187381,
   0.3258257, 0.3436872, 0.354141, 0.3756451, 0.3699905, 0.3768872, 0.3946855, 0.3919207, 0.3894721, 0.3914079, 0.3941796, 0.3854398, 0.3725, 0.3479393, 0.3467695, 0.3312162,
   0.3131218, 0.2954276, 0.2703888, 0.2531982, 0.2309502, 0.2049179, 0.2003055, 0.1639049, 0.1617087, 0.1091821, 0.1258939, 0.08836627, 0.08033472, 0.04747853, 0.03437318, 0.02486807,
   0.02262231 };
   graph = new TGraph(50,gr_rep_95_115_fx6,gr_rep_95_115_fy6);
   graph->SetName("gr_rep_95_115");
   graph->SetTitle("rep3020_95_115_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(4);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(4);
   graph->SetMarkerStyle(24);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_gr_rep_95_1156 = new TH1F("Graph_gr_rep_95_1156","rep3020_95_115_5020gev.txt",100,-2.475,3.405);
   Graph_gr_rep_95_1156->SetMinimum(0.01882566);
   Graph_gr_rep_95_1156->SetMaximum(0.4320624);
   Graph_gr_rep_95_1156->SetDirectory(nullptr);
   Graph_gr_rep_95_1156->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_gr_rep_95_1156->SetLineColor(ci);
   Graph_gr_rep_95_1156->GetXaxis()->SetLabelFont(42);
   Graph_gr_rep_95_1156->GetXaxis()->SetTitleOffset(1);
   Graph_gr_rep_95_1156->GetXaxis()->SetTitleFont(42);
   Graph_gr_rep_95_1156->GetYaxis()->SetLabelFont(42);
   Graph_gr_rep_95_1156->GetYaxis()->SetTitleFont(42);
   Graph_gr_rep_95_1156->GetZaxis()->SetLabelFont(42);
   Graph_gr_rep_95_1156->GetZaxis()->SetTitleOffset(1);
   Graph_gr_rep_95_1156->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_gr_rep_95_1156);
   
   multigraph->Add(graph,"");
   multigraph->Draw("AP");
   multigraph->GetXaxis()->SetLimits(-2.614982, 3.178333);
   multigraph->GetXaxis()->SetTitle("#eta_{dijet}");
   multigraph->GetXaxis()->SetLabelFont(42);
   multigraph->GetXaxis()->SetTitleSize(0.05);
   multigraph->GetXaxis()->SetTitleOffset(1);
   multigraph->GetXaxis()->SetTitleFont(42);
   multigraph->GetYaxis()->SetTitle("d^{2}#sigma / dp_{T}^{ave}d#eta_{dijet}");
   multigraph->GetYaxis()->SetLabelFont(42);
   multigraph->GetYaxis()->SetTitleSize(0.05);
   multigraph->GetYaxis()->SetTitleFont(42);
      tex = new TLatex(0.18,0.87,"95 < p_{T}^{ave} < 115 GeV/c");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
   cPub_3->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_4
   TPad *cPub_4 = new TPad("cPub_4", "cPub_4",0.61,0.01,0.79,0.99);
   cPub_4->Draw();
   cPub_4->cd();
   cPub_4->Range(-3.649503,-0.07696359,3.247301,0.436127);
   cPub_4->SetFillColor(0);
   cPub_4->SetBorderMode(0);
   cPub_4->SetBorderSize(2);
   cPub_4->SetLeftMargin(0.15);
   cPub_4->SetRightMargin(0.01);
   cPub_4->SetTopMargin(0.04);
   cPub_4->SetBottomMargin(0.15);
   cPub_4->SetFrameBorderMode(0);
   cPub_4->SetFrameBorderMode(0);
   
   multigraph = new TMultiGraph();
   multigraph->SetName("");
   multigraph->SetTitle("");
   
   Double_t Graph_fx7[17] = { -2.35165, -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085, 1.7325, 2.155, 2.71835 };
   Double_t Graph_fy7[17] = { 0.000481438, 0.009436364, 0.03727246, 0.08619571, 0.1501913, 0.2184097, 0.2818458, 0.333154, 0.368699, 0.3878701, 0.3863749, 0.3662797, 0.3277707, 0.2726962, 0.2033908, 0.09882862, 0.01268502 };
   graph = new TGraph(17,Graph_fx7,Graph_fy7);
   graph->SetName("Graph");
   graph->SetTitle("pub_115_150_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(2);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(2);
   graph->SetMarkerStyle(20);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_Graph7 = new TH1F("Graph_Graph7","pub_115_150_5020gev.txt",100,-2.85865,3.22535);
   Graph_Graph7->SetMinimum(0.0004332942);
   Graph_Graph7->SetMaximum(0.4266089);
   Graph_Graph7->SetDirectory(nullptr);
   Graph_Graph7->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_Graph7->SetLineColor(ci);
   Graph_Graph7->GetXaxis()->SetLabelFont(42);
   Graph_Graph7->GetXaxis()->SetTitleOffset(1);
   Graph_Graph7->GetXaxis()->SetTitleFont(42);
   Graph_Graph7->GetYaxis()->SetLabelFont(42);
   Graph_Graph7->GetYaxis()->SetTitleFont(42);
   Graph_Graph7->GetZaxis()->SetLabelFont(42);
   Graph_Graph7->GetZaxis()->SetTitleOffset(1);
   Graph_Graph7->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_Graph7);
   
   multigraph->Add(graph,"");
   
   Double_t gr_rep_115_150_fx8[50] = { -1.985, -1.885, -1.785, -1.685, -1.585, -1.485, -1.385, -1.285, -1.185, -1.085, -0.985, -0.885, -0.785, -0.685, -0.585, -0.485, -0.385,
   -0.285, -0.185, -0.085, 0.015, 0.115, 0.215, 0.315, 0.415, 0.515, 0.615, 0.715, 0.815, 0.915, 1.015, 1.115, 1.215,
   1.315, 1.415, 1.515, 1.615, 1.715, 1.815, 1.915, 2.015, 2.115, 2.215, 2.315, 2.415, 2.515, 2.615, 2.715, 2.815,
   2.915 };
   Double_t gr_rep_115_150_fy8[50] = { 0.00768316, 0.01571041, 0.02450747, 0.03665158, 0.0538901, 0.06304722, 0.07740465, 0.1062371, 0.1260791, 0.1465286, 0.1715881, 0.1956476, 0.2106664, 0.2417051, 0.2619418, 0.2794779, 0.3043396,
   0.3124542, 0.3390903, 0.3495219, 0.3577587, 0.3639404, 0.3860116, 0.3819213, 0.3827458, 0.3902368, 0.3958357, 0.38339, 0.3824521, 0.3741975, 0.3492389, 0.3376787, 0.3149773,
   0.2987587, 0.2884779, 0.2648127, 0.2336299, 0.2109025, 0.1905917, 0.1690474, 0.15079, 0.1230137, 0.107656, 0.07627394, 0.05760115, 0.03904027, 0.03510045, 0.02239013, 0.01200093,
   0.008856898 };
   graph = new TGraph(50,gr_rep_115_150_fx8,gr_rep_115_150_fy8);
   graph->SetName("gr_rep_115_150");
   graph->SetTitle("rep3020_115_150_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(4);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(4);
   graph->SetMarkerStyle(24);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_gr_rep_115_1508 = new TH1F("Graph_gr_rep_115_1508","rep3020_115_150_5020gev.txt",100,-2.475,3.405);
   Graph_gr_rep_115_1508->SetMinimum(0.006914844);
   Graph_gr_rep_115_1508->SetMaximum(0.4346509);
   Graph_gr_rep_115_1508->SetDirectory(nullptr);
   Graph_gr_rep_115_1508->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_gr_rep_115_1508->SetLineColor(ci);
   Graph_gr_rep_115_1508->GetXaxis()->SetLabelFont(42);
   Graph_gr_rep_115_1508->GetXaxis()->SetTitleOffset(1);
   Graph_gr_rep_115_1508->GetXaxis()->SetTitleFont(42);
   Graph_gr_rep_115_1508->GetYaxis()->SetLabelFont(42);
   Graph_gr_rep_115_1508->GetYaxis()->SetTitleFont(42);
   Graph_gr_rep_115_1508->GetZaxis()->SetLabelFont(42);
   Graph_gr_rep_115_1508->GetZaxis()->SetTitleOffset(1);
   Graph_gr_rep_115_1508->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_gr_rep_115_1508);
   
   multigraph->Add(graph,"");
   multigraph->Draw("AP");
   multigraph->GetXaxis()->SetLimits(-2.614982, 3.178333);
   multigraph->GetXaxis()->SetTitle("#eta_{dijet}");
   multigraph->GetXaxis()->SetLabelFont(42);
   multigraph->GetXaxis()->SetTitleSize(0.05);
   multigraph->GetXaxis()->SetTitleOffset(1);
   multigraph->GetXaxis()->SetTitleFont(42);
   multigraph->GetYaxis()->SetTitle("d^{2}#sigma / dp_{T}^{ave}d#eta_{dijet}");
   multigraph->GetYaxis()->SetLabelFont(42);
   multigraph->GetYaxis()->SetTitleSize(0.05);
   multigraph->GetYaxis()->SetTitleFont(42);
      tex = new TLatex(0.18,0.87,"115 < p_{T}^{ave} < 150 GeV/c");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
   cPub_4->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_5
   TPad *cPub_5 = new TPad("cPub_5", "cPub_5",0.81,0.01,0.99,0.99);
   cPub_5->Draw();
   cPub_5->cd();
   cPub_5->Range(-3.1925,-0.08386009,3.224167,0.4752072);
   cPub_5->SetFillColor(0);
   cPub_5->SetBorderMode(0);
   cPub_5->SetBorderSize(2);
   cPub_5->SetLeftMargin(0.15);
   cPub_5->SetRightMargin(0.01);
   cPub_5->SetTopMargin(0.04);
   cPub_5->SetBottomMargin(0.15);
   cPub_5->SetFrameBorderMode(0);
   cPub_5->SetFrameBorderMode(0);
   
   multigraph = new TMultiGraph();
   multigraph->SetName("");
   multigraph->SetTitle("");
   
   Double_t Graph_fx9[16] = { -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085, 1.7325, 2.155, 2.71835 };
   Double_t Graph_fy9[16] = { 0.001266443, 0.01181667, 0.04391393, 0.1053819, 0.1870417, 0.2714239, 0.3484368, 0.4027043, 0.4313205, 0.430086, 0.4014251, 0.3462938, 0.2681027, 0.1808697, 0.06846298, 0.004653462 };
   graph = new TGraph(16,Graph_fx9,Graph_fy9);
   graph->SetName("Graph");
   graph->SetTitle("pub_150_400_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(2);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(2);
   graph->SetMarkerStyle(20);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_Graph9 = new TH1F("Graph_Graph9","pub_150_400_5020gev.txt",100,-2.3939,3.1831);
   Graph_Graph9->SetMinimum(0.001139799);
   Graph_Graph9->SetMaximum(0.4743259);
   Graph_Graph9->SetDirectory(nullptr);
   Graph_Graph9->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_Graph9->SetLineColor(ci);
   Graph_Graph9->GetXaxis()->SetLabelFont(42);
   Graph_Graph9->GetXaxis()->SetTitleOffset(1);
   Graph_Graph9->GetXaxis()->SetTitleFont(42);
   Graph_Graph9->GetYaxis()->SetLabelFont(42);
   Graph_Graph9->GetYaxis()->SetTitleFont(42);
   Graph_Graph9->GetZaxis()->SetLabelFont(42);
   Graph_Graph9->GetZaxis()->SetTitleOffset(1);
   Graph_Graph9->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_Graph9);
   
   multigraph->Add(graph,"");
   
   Double_t gr_rep_150_400_fx10[50] = { -1.985, -1.885, -1.785, -1.685, -1.585, -1.485, -1.385, -1.285, -1.185, -1.085, -0.985, -0.885, -0.785, -0.685, -0.585, -0.485, -0.385,
   -0.285, -0.185, -0.085, 0.015, 0.115, 0.215, 0.315, 0.415, 0.515, 0.615, 0.715, 0.815, 0.915, 1.015, 1.115, 1.215,
   1.315, 1.415, 1.515, 1.615, 1.715, 1.815, 1.915, 2.015, 2.115, 2.215, 2.315, 2.415, 2.515, 2.615, 2.715, 2.815,
   2.915 };
   Double_t gr_rep_150_400_fy10[50] = { 0.0008405188, 0.00240456, 0.005170889, 0.01079754, 0.01860324, 0.02994831, 0.04686026, 0.06551688, 0.08778267, 0.1131515, 0.1342011, 0.1671426, 0.1923722, 0.2244534, 0.2488805, 0.2809427, 0.2975313,
   0.3324981, 0.3488986, 0.3728442, 0.3865688, 0.4027382, 0.4076576, 0.4166651, 0.4205837, 0.4241888, 0.4112998, 0.4134776, 0.3976085, 0.3867635, 0.3693168, 0.3447509, 0.3378354,
   0.3068841, 0.2790429, 0.2535901, 0.2241181, 0.1926475, 0.1645257, 0.1395405, 0.1087118, 0.08671238, 0.06618109, 0.04824812, 0.03030609, 0.01994282, 0.01258183, 0.007003314, 0.003171994,
   0.0009371369 };
   graph = new TGraph(50,gr_rep_150_400_fx10,gr_rep_150_400_fy10);
   graph->SetName("gr_rep_150_400");
   graph->SetTitle("rep3020_150_400_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(4);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(4);
   graph->SetMarkerStyle(24);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_gr_rep_150_40010 = new TH1F("Graph_gr_rep_150_40010","rep3020_150_400_5020gev.txt",100,-2.475,3.405);
   Graph_gr_rep_150_40010->SetMinimum(0.0007564669);
   Graph_gr_rep_150_40010->SetMaximum(0.4665237);
   Graph_gr_rep_150_40010->SetDirectory(nullptr);
   Graph_gr_rep_150_40010->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_gr_rep_150_40010->SetLineColor(ci);
   Graph_gr_rep_150_40010->GetXaxis()->SetLabelFont(42);
   Graph_gr_rep_150_40010->GetXaxis()->SetTitleOffset(1);
   Graph_gr_rep_150_40010->GetXaxis()->SetTitleFont(42);
   Graph_gr_rep_150_40010->GetYaxis()->SetLabelFont(42);
   Graph_gr_rep_150_40010->GetYaxis()->SetTitleFont(42);
   Graph_gr_rep_150_40010->GetZaxis()->SetLabelFont(42);
   Graph_gr_rep_150_40010->GetZaxis()->SetTitleOffset(1);
   Graph_gr_rep_150_40010->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_gr_rep_150_40010);
   
   multigraph->Add(graph,"");
   multigraph->Draw("AP");
   multigraph->GetXaxis()->SetLimits(-2.23, 3.16);
   multigraph->GetXaxis()->SetTitle("#eta_{dijet}");
   multigraph->GetXaxis()->SetLabelFont(42);
   multigraph->GetXaxis()->SetTitleSize(0.05);
   multigraph->GetXaxis()->SetTitleOffset(1);
   multigraph->GetXaxis()->SetTitleFont(42);
   multigraph->GetYaxis()->SetTitle("d^{2}#sigma / dp_{T}^{ave}d#eta_{dijet}");
   multigraph->GetYaxis()->SetLabelFont(42);
   multigraph->GetYaxis()->SetTitleSize(0.05);
   multigraph->GetYaxis()->SetTitleFont(42);
      tex = new TLatex(0.18,0.87,"150 < p_{T}^{ave} < 400 GeV/c");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
   cPub_5->Modified();
   cPub->cd();
   cPub->Modified();
   cPub->cd();
   cPub->SetSelected(cPub);
}
