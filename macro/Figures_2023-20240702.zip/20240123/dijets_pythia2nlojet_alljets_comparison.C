#ifdef __CLING__
#pragma cling optimize(0)
#endif
void dijets_pythia2nlojet_alljets_comparison()
{
//=========Macro generated from canvas: cPub/cPub
//=========  (Tue Jan 23 12:24:01 2024) by ROOT version 6.30/02
   TCanvas *cPub = new TCanvas("cPub", "cPub",0,67,1710,777);
   gStyle->SetOptStat(0);
   gStyle->SetOptTitle(0);
   cPub->Range(0,0,1,1);
   cPub->SetFillColor(0);
   cPub->SetBorderMode(0);
   cPub->SetBorderSize(2);
   cPub->SetFrameBorderMode(0);
  
// ------------>Primitives in pad: cPub_1
   TPad *cPub_1__10 = new TPad("cPub_1", "cPub_1",0.01,0.51,0.19,0.99);
   cPub_1__10->Draw();
   cPub_1__10->cd();
   cPub_1__10->Range(-4.170857,-0.09027542,3.214857,0.3988211);
   cPub_1__10->SetFillColor(0);
   cPub_1__10->SetBorderMode(0);
   cPub_1__10->SetBorderSize(2);
   cPub_1__10->SetLeftMargin(0.15);
   cPub_1__10->SetRightMargin(0.01);
   cPub_1__10->SetTopMargin(0.04);
   cPub_1__10->SetBottomMargin(0.15);
   cPub_1__10->SetFrameBorderMode(0);
   cPub_1__10->SetFrameBorderMode(0);
   
   TMultiGraph *multigraph = new TMultiGraph();
   multigraph->SetName("mgComp_55_75");
   multigraph->SetTitle("");
   
   Double_t grMy_55_75_fx21[21] = { -2.781, -2.499, -2.217, -1.935, -1.653, -1.371, -1.089, -0.807, -0.525, -0.243, 0.039, 0.321, 0.603, 0.885, 1.167, 1.449, 1.731,
   2.013, 2.295, 2.577, 2.859 };
   Double_t grMy_55_75_fy21[21] = { 0.001322342, 0.009531299, 0.02657428, 0.05858658, 0.09829554, 0.1533309, 0.1783155, 0.2317834, 0.2805722, 0.3170782, 0.3476585, 0.3612496, 0.3494177, 0.32636, 0.2862862, 0.2363139, 0.1789498,
   0.1164589, 0.07467685, 0.03643619, 0.01149619 };
   TGraph *graph = new TGraph(21,grMy_55_75_fx21,grMy_55_75_fy21);
   graph->SetName("grMy_55_75");
   graph->SetTitle("rep3020_pt1pt2_55_75_mu05_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(4);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(4);
   graph->SetMarkerStyle(24);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_grMy_55_7521 = new TH1F("Graph_grMy_55_7521","rep3020_pt1pt2_55_75_mu05_5020gev.txt",100,-3.345,3.423);
   Graph_grMy_55_7521->SetMinimum(0.5398553);
   Graph_grMy_55_7521->SetMaximum(180.1966);
   Graph_grMy_55_7521->SetDirectory(nullptr);
   Graph_grMy_55_7521->SetStats(0);

   Int_t ci;      // for color index setting
   TColor *color; // for color definition with alpha
   ci = TColor::GetColor("#000099");
   Graph_grMy_55_7521->SetLineColor(ci);
   Graph_grMy_55_7521->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grMy_55_7521->GetXaxis()->SetLabelFont(42);
   Graph_grMy_55_7521->GetXaxis()->SetTitleSize(0.05);
   Graph_grMy_55_7521->GetXaxis()->SetTitleOffset(1);
   Graph_grMy_55_7521->GetXaxis()->SetTitleFont(42);
   Graph_grMy_55_7521->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grMy_55_7521->GetYaxis()->SetLabelFont(42);
   Graph_grMy_55_7521->GetYaxis()->SetTitleSize(0.05);
   Graph_grMy_55_7521->GetYaxis()->SetTitleFont(42);
   Graph_grMy_55_7521->GetZaxis()->SetLabelFont(42);
   Graph_grMy_55_7521->GetZaxis()->SetTitleOffset(1);
   Graph_grMy_55_7521->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grMy_55_7521);
   
   multigraph->Add(graph,"AP");
   
   Double_t grPub_55_75_fx22[18] = { -2.77415, -2.35165, -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085, 1.7325, 2.155,
   2.71835 };
   Double_t grPub_55_75_fy22[18] = { 0.001096712, 0.01851103, 0.06135381, 0.1033289, 0.1511131, 0.1993502, 0.2432752, 0.2838158, 0.3174255, 0.3389175, 0.3503245, 0.3498483, 0.3314536, 0.301076, 0.2578431, 0.2063402, 0.1191301,
   0.02725358 };
   graph = new TGraph(18,grPub_55_75_fx22,grPub_55_75_fy22);
   graph->SetName("grPub_55_75");
   graph->SetTitle("pub_55_75_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(2);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(2);
   graph->SetMarkerStyle(20);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_grPub_55_7522 = new TH1F("Graph_grPub_55_7522","pub_55_75_5020gev.txt",100,-3.3234,3.2676);
   Graph_grPub_55_7522->SetMinimum(51.86138);
   Graph_grPub_55_7522->SetMaximum(20241.78);
   Graph_grPub_55_7522->SetDirectory(nullptr);
   Graph_grPub_55_7522->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grPub_55_7522->SetLineColor(ci);
   Graph_grPub_55_7522->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grPub_55_7522->GetXaxis()->SetLabelFont(42);
   Graph_grPub_55_7522->GetXaxis()->SetTitleSize(0.05);
   Graph_grPub_55_7522->GetXaxis()->SetTitleOffset(1);
   Graph_grPub_55_7522->GetXaxis()->SetTitleFont(42);
   Graph_grPub_55_7522->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grPub_55_7522->GetYaxis()->SetLabelFont(42);
   Graph_grPub_55_7522->GetYaxis()->SetTitleSize(0.05);
   Graph_grPub_55_7522->GetYaxis()->SetTitleFont(42);
   Graph_grPub_55_7522->GetZaxis()->SetLabelFont(42);
   Graph_grPub_55_7522->GetZaxis()->SetTitleOffset(1);
   Graph_grPub_55_7522->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grPub_55_7522);
   
   multigraph->Add(graph,"AP");
   
   Double_t grPythia_55_75_fx23[21] = { -2.781, -2.499, -2.217, -1.935, -1.653, -1.371, -1.089, -0.807, -0.525, -0.243, 0.039, 0.321, 0.603, 0.885, 1.167, 1.449, 1.731,
   2.013, 2.295, 2.577, 2.859 };
   Double_t grPythia_55_75_fy23[21] = { 0.0004451199, 0.008077236, 0.02634153, 0.05537728, 0.08503654, 0.1424564, 0.1809185, 0.2346296, 0.2797963, 0.3046218, 0.3390469, 0.3415529, 0.3418751, 0.3173753, 0.2857992, 0.2475666, 0.1926098,
   0.1333523, 0.07867335, 0.03631749, 0.008536452 };
   graph = new TGraph(21,grPythia_55_75_fx23,grPythia_55_75_fy23);
   graph->SetName("grPythia_55_75");
   graph->SetTitle("PYTHIA dijet #eta");
   graph->SetLineColor(15);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(15);
   graph->SetMarkerStyle(41);
   graph->SetMarkerSize(1.3);
   
   TH1F *Graph_grPythia_55_7523 = new TH1F("Graph_grPythia_55_7523","PYTHIA dijet #eta",100,-3.345,3.423);
   Graph_grPythia_55_7523->SetMinimum(0.008610263);
   Graph_grPythia_55_7523->SetMaximum(8.081756);
   Graph_grPythia_55_7523->SetDirectory(nullptr);
   Graph_grPythia_55_7523->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grPythia_55_7523->SetLineColor(ci);
   Graph_grPythia_55_7523->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grPythia_55_7523->GetXaxis()->SetLabelFont(42);
   Graph_grPythia_55_7523->GetXaxis()->SetTitleSize(0.05);
   Graph_grPythia_55_7523->GetXaxis()->SetTitleOffset(1);
   Graph_grPythia_55_7523->GetXaxis()->SetTitleFont(42);
   Graph_grPythia_55_7523->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grPythia_55_7523->GetYaxis()->SetLabelFont(42);
   Graph_grPythia_55_7523->GetYaxis()->SetTitleSize(0.05);
   Graph_grPythia_55_7523->GetYaxis()->SetTitleFont(42);
   Graph_grPythia_55_7523->GetZaxis()->SetLabelFont(42);
   Graph_grPythia_55_7523->GetZaxis()->SetTitleOffset(1);
   Graph_grPythia_55_7523->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grPythia_55_7523);
   
   multigraph->Add(graph,"P");
   multigraph->Draw("AP");
   multigraph->GetXaxis()->SetLimits(-3.063, 3.141);
   multigraph->GetXaxis()->SetTitle("#eta_{dijet}");
   multigraph->GetXaxis()->SetLabelFont(42);
   multigraph->GetXaxis()->SetTitleSize(0.05);
   multigraph->GetXaxis()->SetTitleOffset(1);
   multigraph->GetXaxis()->SetTitleFont(42);
   multigraph->GetYaxis()->SetTitle("1/N_{dijet} d#sigma/d#eta_{dijet}");
   multigraph->GetYaxis()->SetLabelFont(42);
   multigraph->GetYaxis()->SetTitleSize(0.05);
   multigraph->GetYaxis()->SetTitleFont(42);
   TLatex *   tex = new TLatex(0.18,0.87,"55 < p_{T}^{ave} < 75 GeV/c");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
      tex = new TLatex(0.18,0.92,"NLOJet++ pPb #sqrt{s_{NN}}=5020 GeV");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
      tex = new TLatex(0.18,0.82,"x_{#mu}^{2} p_{T, 1} p_{T, 2}");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
      tex = new TLatex(0.18,0.76,"x_{#mu}=0.5");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
   cPub_1__10->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_2
   TPad *cPub_2__11 = new TPad("cPub_2", "cPub_2",0.21,0.51,0.39,0.99);
   cPub_2__11->Draw();
   cPub_2__11->cd();
   cPub_2__11->Range(-4.170857,-0.09319608,3.214857,0.4064187);
   cPub_2__11->SetFillColor(0);
   cPub_2__11->SetBorderMode(0);
   cPub_2__11->SetBorderSize(2);
   cPub_2__11->SetLeftMargin(0.15);
   cPub_2__11->SetRightMargin(0.01);
   cPub_2__11->SetTopMargin(0.04);
   cPub_2__11->SetBottomMargin(0.15);
   cPub_2__11->SetFrameBorderMode(0);
   cPub_2__11->SetFrameBorderMode(0);
   
   multigraph = new TMultiGraph();
   multigraph->SetName("mgComp_75_95");
   multigraph->SetTitle("");
   
   Double_t grMy_75_95_fx24[21] = { -2.781, -2.499, -2.217, -1.935, -1.653, -1.371, -1.089, -0.807, -0.525, -0.243, 0.039, 0.321, 0.603, 0.885, 1.167, 1.449, 1.731,
   2.013, 2.295, 2.577, 2.859 };
   Double_t grMy_75_95_fy24[21] = { 0.0001410445, 0.003557399, 0.01635197, 0.04292571, 0.07853829, 0.1380229, 0.165497, 0.2273673, 0.274152, 0.3233933, 0.3420939, 0.3588983, 0.3586138, 0.3354126, 0.291821, 0.238295, 0.178779,
   0.1300265, 0.06976238, 0.03566492, 0.006498315 };
   graph = new TGraph(21,grMy_75_95_fx24,grMy_75_95_fy24);
   graph->SetName("grMy_75_95");
   graph->SetTitle("rep3020_pt1pt2_75_95_mu05_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(4);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(4);
   graph->SetMarkerStyle(24);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_grMy_75_9524 = new TH1F("Graph_grMy_75_9524","rep3020_pt1pt2_75_95_mu05_5020gev.txt",100,-3.345,3.423);
   Graph_grMy_75_9524->SetMinimum(0.01366037);
   Graph_grMy_75_9524->SetMaximum(42.48273);
   Graph_grMy_75_9524->SetDirectory(nullptr);
   Graph_grMy_75_9524->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grMy_75_9524->SetLineColor(ci);
   Graph_grMy_75_9524->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grMy_75_9524->GetXaxis()->SetLabelFont(42);
   Graph_grMy_75_9524->GetXaxis()->SetTitleSize(0.05);
   Graph_grMy_75_9524->GetXaxis()->SetTitleOffset(1);
   Graph_grMy_75_9524->GetXaxis()->SetTitleFont(42);
   Graph_grMy_75_9524->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grMy_75_9524->GetYaxis()->SetLabelFont(42);
   Graph_grMy_75_9524->GetYaxis()->SetTitleSize(0.05);
   Graph_grMy_75_9524->GetYaxis()->SetTitleFont(42);
   Graph_grMy_75_9524->GetZaxis()->SetLabelFont(42);
   Graph_grMy_75_9524->GetZaxis()->SetTitleOffset(1);
   Graph_grMy_75_9524->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grMy_75_9524);
   
   multigraph->Add(graph,"AP");
   
   Double_t grPub_75_95_fx25[17] = { -2.35165, -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085, 1.7325, 2.155, 2.71835 };
   Double_t grPub_75_95_fy25[17] = { 0.008056904, 0.04029148, 0.08253176, 0.1341185, 0.1902633, 0.2405449, 0.2890796, 0.3278334, 0.3527867, 0.3680392, 0.3661056, 0.3475721, 0.3151789, 0.2691118, 0.2120753, 0.1183062, 0.02361223 };
   graph = new TGraph(17,grPub_75_95_fx25,grPub_75_95_fy25);
   graph->SetName("grPub_75_95");
   graph->SetTitle("pub_75_95_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(2);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(2);
   graph->SetMarkerStyle(20);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_grPub_75_9525 = new TH1F("Graph_grPub_75_9525","pub_75_95_5020gev.txt",100,-2.85865,3.22535);
   Graph_grPub_75_9525->SetMinimum(89.67204);
   Graph_grPub_75_9525->SetMaximum(4996.524);
   Graph_grPub_75_9525->SetDirectory(nullptr);
   Graph_grPub_75_9525->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grPub_75_9525->SetLineColor(ci);
   Graph_grPub_75_9525->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grPub_75_9525->GetXaxis()->SetLabelFont(42);
   Graph_grPub_75_9525->GetXaxis()->SetTitleSize(0.05);
   Graph_grPub_75_9525->GetXaxis()->SetTitleOffset(1);
   Graph_grPub_75_9525->GetXaxis()->SetTitleFont(42);
   Graph_grPub_75_9525->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grPub_75_9525->GetYaxis()->SetLabelFont(42);
   Graph_grPub_75_9525->GetYaxis()->SetTitleSize(0.05);
   Graph_grPub_75_9525->GetYaxis()->SetTitleFont(42);
   Graph_grPub_75_9525->GetZaxis()->SetLabelFont(42);
   Graph_grPub_75_9525->GetZaxis()->SetTitleOffset(1);
   Graph_grPub_75_9525->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grPub_75_9525);
   
   multigraph->Add(graph,"AP");
   
   Double_t grPythia_75_95_fx26[21] = { -2.781, -2.499, -2.217, -1.935, -1.653, -1.371, -1.089, -0.807, -0.525, -0.243, 0.039, 0.321, 0.603, 0.885, 1.167, 1.449, 1.731,
   2.013, 2.295, 2.577, 2.859 };
   Double_t grPythia_75_95_fy26[21] = { 0, 0.001986117, 0.01261614, 0.03357417, 0.07050811, 0.1176476, 0.1710314, 0.2271224, 0.2830069, 0.3080696, 0.3448517, 0.3639478, 0.3601881, 0.3350896, 0.2992629, 0.2487096, 0.1915436,
   0.1326339, 0.0808289, 0.03322432, 0.007341451 };
   graph = new TGraph(21,grPythia_75_95_fx26,grPythia_75_95_fy26);
   graph->SetName("grPythia_75_95");
   graph->SetTitle("PYTHIA dijet #eta");
   graph->SetLineColor(15);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(15);
   graph->SetMarkerStyle(41);
   graph->SetMarkerSize(1.3);
   
   TH1F *Graph_grPythia_75_9526 = new TH1F("Graph_grPythia_75_9526","PYTHIA dijet #eta",100,-3.345,3.423);
   Graph_grPythia_75_9526->SetMinimum(0);
   Graph_grPythia_75_9526->SetMaximum(1.98643);
   Graph_grPythia_75_9526->SetDirectory(nullptr);
   Graph_grPythia_75_9526->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grPythia_75_9526->SetLineColor(ci);
   Graph_grPythia_75_9526->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grPythia_75_9526->GetXaxis()->SetLabelFont(42);
   Graph_grPythia_75_9526->GetXaxis()->SetTitleSize(0.05);
   Graph_grPythia_75_9526->GetXaxis()->SetTitleOffset(1);
   Graph_grPythia_75_9526->GetXaxis()->SetTitleFont(42);
   Graph_grPythia_75_9526->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grPythia_75_9526->GetYaxis()->SetLabelFont(42);
   Graph_grPythia_75_9526->GetYaxis()->SetTitleSize(0.05);
   Graph_grPythia_75_9526->GetYaxis()->SetTitleFont(42);
   Graph_grPythia_75_9526->GetZaxis()->SetLabelFont(42);
   Graph_grPythia_75_9526->GetZaxis()->SetTitleOffset(1);
   Graph_grPythia_75_9526->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grPythia_75_9526);
   
   multigraph->Add(graph,"P");
   multigraph->Draw("AP");
   multigraph->GetXaxis()->SetLimits(-3.063, 3.141);
   multigraph->GetXaxis()->SetTitle("#eta_{dijet}");
   multigraph->GetXaxis()->SetLabelFont(42);
   multigraph->GetXaxis()->SetTitleSize(0.05);
   multigraph->GetXaxis()->SetTitleOffset(1);
   multigraph->GetXaxis()->SetTitleFont(42);
   multigraph->GetYaxis()->SetTitle("1/N_{dijet} d#sigma/d#eta_{dijet}");
   multigraph->GetYaxis()->SetLabelFont(42);
   multigraph->GetYaxis()->SetTitleSize(0.05);
   multigraph->GetYaxis()->SetTitleFont(42);
      tex = new TLatex(0.18,0.87,"75 < p_{T}^{ave} < 95 GeV/c");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
   
   TLegend *leg = new TLegend(0.4,0.2,0.8,0.35,NULL,"brNDC");
   leg->SetBorderSize(0);
   leg->SetTextSize(0.05);
   leg->SetLineColor(1);
   leg->SetLineStyle(1);
   leg->SetLineWidth(1);
   leg->SetFillColor(0);
   leg->SetFillStyle(1001);
   TLegendEntry *entry=leg->AddEntry("grMy_75_95","My NLOJet++","p");
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(1);
   entry->SetMarkerColor(4);
   entry->SetMarkerStyle(24);
   entry->SetMarkerSize(1.2);
   entry->SetTextFont(42);
   entry=leg->AddEntry("grPub_75_95","Pub NLOJet++","p");
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(1);
   entry->SetMarkerColor(2);
   entry->SetMarkerStyle(20);
   entry->SetMarkerSize(1.2);
   entry->SetTextFont(42);
   entry=leg->AddEntry("grPythia_75_95","PYTHIA","p");
   entry->SetLineColor(1);
   entry->SetLineStyle(1);
   entry->SetLineWidth(1);
   entry->SetMarkerColor(15);
   entry->SetMarkerStyle(41);
   entry->SetMarkerSize(1.3);
   entry->SetTextFont(42);
   leg->Draw();
      tex = new TLatex(-0.2233533,0.08805784,"2+ jets");
   tex->SetLineWidth(2);
   tex->Draw();
   cPub_2__11->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_3
   TPad *cPub_3__12 = new TPad("cPub_3", "cPub_3",0.41,0.51,0.59,0.99);
   cPub_3__12->Draw();
   cPub_3__12->cd();
   cPub_3__12->Range(-4.170857,-0.0949371,3.214857,0.4132663);
   cPub_3__12->SetFillColor(0);
   cPub_3__12->SetBorderMode(0);
   cPub_3__12->SetBorderSize(2);
   cPub_3__12->SetLeftMargin(0.15);
   cPub_3__12->SetRightMargin(0.01);
   cPub_3__12->SetTopMargin(0.04);
   cPub_3__12->SetBottomMargin(0.15);
   cPub_3__12->SetFrameBorderMode(0);
   cPub_3__12->SetFrameBorderMode(0);
   
   multigraph = new TMultiGraph();
   multigraph->SetName("mgComp_95_115");
   multigraph->SetTitle("");
   
   Double_t grMy_95_115_fx27[21] = { -2.781, -2.499, -2.217, -1.935, -1.653, -1.371, -1.089, -0.807, -0.525, -0.243, 0.039, 0.321, 0.603, 0.885, 1.167, 1.449, 1.731,
   2.013, 2.295, 2.577, 2.859 };
   Double_t grMy_95_115_fy27[21] = { 4.542687e-06, 0.0006472828, 0.007288357, 0.02726003, 0.06012117, 0.09671393, 0.1645515, 0.2214603, 0.2811214, 0.3189541, 0.3636198, 0.3713302, 0.3681504, 0.3514914, 0.3051151, 0.2486084, 0.1880379,
   0.1300552, 0.06468442, 0.03059746, 0.005649037 };
   graph = new TGraph(21,grMy_95_115_fx27,grMy_95_115_fy27);
   graph->SetName("grMy_95_115");
   graph->SetTitle("rep3020_pt1pt2_95_115_mu05_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(4);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(4);
   graph->SetMarkerStyle(24);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_grMy_95_11527 = new TH1F("Graph_grMy_95_11527","rep3020_pt1pt2_95_115_mu05_5020gev.txt",100,-3.345,3.423);
   Graph_grMy_95_11527->SetMinimum(0.0001363689);
   Graph_grMy_95_11527->SetMaximum(13.62424);
   Graph_grMy_95_11527->SetDirectory(nullptr);
   Graph_grMy_95_11527->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grMy_95_11527->SetLineColor(ci);
   Graph_grMy_95_11527->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grMy_95_11527->GetXaxis()->SetLabelFont(42);
   Graph_grMy_95_11527->GetXaxis()->SetTitleSize(0.05);
   Graph_grMy_95_11527->GetXaxis()->SetTitleOffset(1);
   Graph_grMy_95_11527->GetXaxis()->SetTitleFont(42);
   Graph_grMy_95_11527->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grMy_95_11527->GetYaxis()->SetLabelFont(42);
   Graph_grMy_95_11527->GetYaxis()->SetTitleSize(0.05);
   Graph_grMy_95_11527->GetYaxis()->SetTitleFont(42);
   Graph_grMy_95_11527->GetZaxis()->SetLabelFont(42);
   Graph_grMy_95_11527->GetZaxis()->SetTitleOffset(1);
   Graph_grMy_95_11527->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grMy_95_11527);
   
   multigraph->Add(graph,"AP");
   
   Double_t grPub_95_115_fx28[17] = { -2.35165, -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085, 1.7325, 2.155, 2.71835 };
   Double_t grPub_95_115_fy28[17] = { 0.002600559, 0.0225542, 0.05955763, 0.1118572, 0.1714378, 0.2313938, 0.2851709, 0.3282355, 0.3590886, 0.374227, 0.3740803, 0.3538156, 0.3190078, 0.270303, 0.2093777, 0.1102455, 0.01865911 };
   graph = new TGraph(17,grPub_95_115_fx28,grPub_95_115_fy28);
   graph->SetName("grPub_95_115");
   graph->SetTitle("pub_95_115_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(2);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(2);
   graph->SetMarkerStyle(20);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_grPub_95_11528 = new TH1F("Graph_grPub_95_11528","pub_95_115_5020gev.txt",100,-2.85865,3.22535);
   Graph_grPub_95_11528->SetMinimum(9.282708);
   Graph_grPub_95_11528->SetMaximum(1631.619);
   Graph_grPub_95_11528->SetDirectory(nullptr);
   Graph_grPub_95_11528->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grPub_95_11528->SetLineColor(ci);
   Graph_grPub_95_11528->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grPub_95_11528->GetXaxis()->SetLabelFont(42);
   Graph_grPub_95_11528->GetXaxis()->SetTitleSize(0.05);
   Graph_grPub_95_11528->GetXaxis()->SetTitleOffset(1);
   Graph_grPub_95_11528->GetXaxis()->SetTitleFont(42);
   Graph_grPub_95_11528->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grPub_95_11528->GetYaxis()->SetLabelFont(42);
   Graph_grPub_95_11528->GetYaxis()->SetTitleSize(0.05);
   Graph_grPub_95_11528->GetYaxis()->SetTitleFont(42);
   Graph_grPub_95_11528->GetZaxis()->SetLabelFont(42);
   Graph_grPub_95_11528->GetZaxis()->SetTitleOffset(1);
   Graph_grPub_95_11528->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grPub_95_11528);
   
   multigraph->Add(graph,"AP");
   
   Double_t grPythia_95_115_fx29[21] = { -2.781, -2.499, -2.217, -1.935, -1.653, -1.371, -1.089, -0.807, -0.525, -0.243, 0.039, 0.321, 0.603, 0.885, 1.167, 1.449, 1.731,
   2.013, 2.295, 2.577, 2.859 };
   Double_t grPythia_95_115_fy29[21] = { 0, 0.0003710806, 0.005182854, 0.02239557, 0.06091806, 0.1052443, 0.159361, 0.2175928, 0.2768193, 0.3161823, 0.3544307, 0.3727185, 0.3698374, 0.3482414, 0.3083258, 0.262315, 0.1950377,
   0.1263392, 0.06550106, 0.02767849, 0.005094023 };
   graph = new TGraph(21,grPythia_95_115_fx29,grPythia_95_115_fy29);
   graph->SetName("grPythia_95_115");
   graph->SetTitle("PYTHIA dijet #eta");
   graph->SetLineColor(15);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(15);
   graph->SetMarkerStyle(41);
   graph->SetMarkerSize(1.3);
   
   TH1F *Graph_grPythia_95_11529 = new TH1F("Graph_grPythia_95_11529","PYTHIA dijet #eta",100,-3.345,3.423);
   Graph_grPythia_95_11529->SetMinimum(0);
   Graph_grPythia_95_11529->SetMaximum(0.6271754);
   Graph_grPythia_95_11529->SetDirectory(nullptr);
   Graph_grPythia_95_11529->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grPythia_95_11529->SetLineColor(ci);
   Graph_grPythia_95_11529->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grPythia_95_11529->GetXaxis()->SetLabelFont(42);
   Graph_grPythia_95_11529->GetXaxis()->SetTitleSize(0.05);
   Graph_grPythia_95_11529->GetXaxis()->SetTitleOffset(1);
   Graph_grPythia_95_11529->GetXaxis()->SetTitleFont(42);
   Graph_grPythia_95_11529->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grPythia_95_11529->GetYaxis()->SetLabelFont(42);
   Graph_grPythia_95_11529->GetYaxis()->SetTitleSize(0.05);
   Graph_grPythia_95_11529->GetYaxis()->SetTitleFont(42);
   Graph_grPythia_95_11529->GetZaxis()->SetLabelFont(42);
   Graph_grPythia_95_11529->GetZaxis()->SetTitleOffset(1);
   Graph_grPythia_95_11529->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grPythia_95_11529);
   
   multigraph->Add(graph,"P");
   multigraph->Draw("AP");
   multigraph->GetXaxis()->SetLimits(-3.063, 3.141);
   multigraph->GetXaxis()->SetTitle("#eta_{dijet}");
   multigraph->GetXaxis()->SetLabelFont(42);
   multigraph->GetXaxis()->SetTitleSize(0.05);
   multigraph->GetXaxis()->SetTitleOffset(1);
   multigraph->GetXaxis()->SetTitleFont(42);
   multigraph->GetYaxis()->SetTitle("1/N_{dijet} d#sigma/d#eta_{dijet}");
   multigraph->GetYaxis()->SetLabelFont(42);
   multigraph->GetYaxis()->SetTitleSize(0.05);
   multigraph->GetYaxis()->SetTitleFont(42);
      tex = new TLatex(0.18,0.87,"95 < p_{T}^{ave} < 115 GeV/c");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
   cPub_3__12->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_4
   TPad *cPub_4__13 = new TPad("cPub_4", "cPub_4",0.61,0.51,0.79,0.99);
   cPub_4__13->Draw();
   cPub_4__13->cd();
   cPub_4__13->Range(-4.170857,-0.09845849,3.214857,0.4285699);
   cPub_4__13->SetFillColor(0);
   cPub_4__13->SetBorderMode(0);
   cPub_4__13->SetBorderSize(2);
   cPub_4__13->SetLeftMargin(0.15);
   cPub_4__13->SetRightMargin(0.01);
   cPub_4__13->SetTopMargin(0.04);
   cPub_4__13->SetBottomMargin(0.15);
   cPub_4__13->SetFrameBorderMode(0);
   cPub_4__13->SetFrameBorderMode(0);
   
   multigraph = new TMultiGraph();
   multigraph->SetName("mgComp_115_150");
   multigraph->SetTitle("");
   
   Double_t grMy_115_150_fx30[21] = { -2.781, -2.499, -2.217, -1.935, -1.653, -1.371, -1.089, -0.807, -0.525, -0.243, 0.039, 0.321, 0.603, 0.885, 1.167, 1.449, 1.731,
   2.013, 2.295, 2.577, 2.859 };
   Double_t grMy_115_150_fy30[21] = { 0, 1.285195e-05, 0.001777758, 0.01239136, 0.04241947, 0.08888218, 0.1517956, 0.2132503, 0.2733886, 0.326279, 0.3652106, 0.3880845, 0.3867372, 0.3624787, 0.3172012, 0.2563116, 0.1870352,
   0.1195766, 0.06605715, 0.02394148, 0.003866548 };
   graph = new TGraph(21,grMy_115_150_fx30,grMy_115_150_fy30);
   graph->SetName("grMy_115_150");
   graph->SetTitle("rep3020_pt1pt2_115_150_mu05_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(4);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(4);
   graph->SetMarkerStyle(24);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_grMy_115_15030 = new TH1F("Graph_grMy_115_15030","rep3020_pt1pt2_115_150_mu05_5020gev.txt",100,-3.345,3.423);
   Graph_grMy_115_15030->SetMinimum(0);
   Graph_grMy_115_15030->SetMaximum(7.177683);
   Graph_grMy_115_15030->SetDirectory(nullptr);
   Graph_grMy_115_15030->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grMy_115_15030->SetLineColor(ci);
   Graph_grMy_115_15030->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grMy_115_15030->GetXaxis()->SetLabelFont(42);
   Graph_grMy_115_15030->GetXaxis()->SetTitleSize(0.05);
   Graph_grMy_115_15030->GetXaxis()->SetTitleOffset(1);
   Graph_grMy_115_15030->GetXaxis()->SetTitleFont(42);
   Graph_grMy_115_15030->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grMy_115_15030->GetYaxis()->SetLabelFont(42);
   Graph_grMy_115_15030->GetYaxis()->SetTitleSize(0.05);
   Graph_grMy_115_15030->GetYaxis()->SetTitleFont(42);
   Graph_grMy_115_15030->GetZaxis()->SetLabelFont(42);
   Graph_grMy_115_15030->GetZaxis()->SetTitleOffset(1);
   Graph_grMy_115_15030->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grMy_115_15030);
   
   multigraph->Add(graph,"AP");
   
   Double_t grPub_115_150_fx31[17] = { -2.35165, -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085, 1.7325, 2.155, 2.71835 };
   Double_t grPub_115_150_fy31[17] = { 0.000481438, 0.009436364, 0.03727246, 0.08619571, 0.1501913, 0.2184097, 0.2818458, 0.333154, 0.368699, 0.3878701, 0.3863749, 0.3662797, 0.3277707, 0.2726962, 0.2033908, 0.09882862, 0.01268502 };
   graph = new TGraph(17,grPub_115_150_fx31,grPub_115_150_fy31);
   graph->SetName("grPub_115_150");
   graph->SetTitle("pub_115_150_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(2);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(2);
   graph->SetMarkerStyle(20);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_grPub_115_15031 = new TH1F("Graph_grPub_115_15031","pub_115_150_5020gev.txt",100,-2.85865,3.22535);
   Graph_grPub_115_15031->SetMinimum(0.5051467);
   Graph_grPub_115_15031->SetMaximum(497.3528);
   Graph_grPub_115_15031->SetDirectory(nullptr);
   Graph_grPub_115_15031->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grPub_115_15031->SetLineColor(ci);
   Graph_grPub_115_15031->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grPub_115_15031->GetXaxis()->SetLabelFont(42);
   Graph_grPub_115_15031->GetXaxis()->SetTitleSize(0.05);
   Graph_grPub_115_15031->GetXaxis()->SetTitleOffset(1);
   Graph_grPub_115_15031->GetXaxis()->SetTitleFont(42);
   Graph_grPub_115_15031->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grPub_115_15031->GetYaxis()->SetLabelFont(42);
   Graph_grPub_115_15031->GetYaxis()->SetTitleSize(0.05);
   Graph_grPub_115_15031->GetYaxis()->SetTitleFont(42);
   Graph_grPub_115_15031->GetZaxis()->SetLabelFont(42);
   Graph_grPub_115_15031->GetZaxis()->SetTitleOffset(1);
   Graph_grPub_115_15031->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grPub_115_15031);
   
   multigraph->Add(graph,"AP");
   
   Double_t grPythia_115_150_fx32[21] = { -2.781, -2.499, -2.217, -1.935, -1.653, -1.371, -1.089, -0.807, -0.525, -0.243, 0.039, 0.321, 0.603, 0.885, 1.167, 1.449, 1.731,
   2.013, 2.295, 2.577, 2.859 };
   Double_t grPythia_115_150_fy32[21] = { 0, 9.504999e-05, 0.001981539, 0.008242995, 0.03632197, 0.08604975, 0.1488978, 0.2141895, 0.2831718, 0.3218278, 0.3644568, 0.3794675, 0.3766753, 0.3682843, 0.323136, 0.2677871, 0.1929629,
   0.1191683, 0.05939876, 0.01966255, 0.00270299 };
   graph = new TGraph(21,grPythia_115_150_fx32,grPythia_115_150_fy32);
   graph->SetName("grPythia_115_150");
   graph->SetTitle("PYTHIA dijet #eta");
   graph->SetLineColor(15);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(15);
   graph->SetMarkerStyle(41);
   graph->SetMarkerSize(1.3);
   
   TH1F *Graph_grPythia_115_15032 = new TH1F("Graph_grPythia_115_15032","PYTHIA dijet #eta",100,-3.345,3.423);
   Graph_grPythia_115_15032->SetMinimum(0);
   Graph_grPythia_115_15032->SetMaximum(0.3523491);
   Graph_grPythia_115_15032->SetDirectory(nullptr);
   Graph_grPythia_115_15032->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grPythia_115_15032->SetLineColor(ci);
   Graph_grPythia_115_15032->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grPythia_115_15032->GetXaxis()->SetLabelFont(42);
   Graph_grPythia_115_15032->GetXaxis()->SetTitleSize(0.05);
   Graph_grPythia_115_15032->GetXaxis()->SetTitleOffset(1);
   Graph_grPythia_115_15032->GetXaxis()->SetTitleFont(42);
   Graph_grPythia_115_15032->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grPythia_115_15032->GetYaxis()->SetLabelFont(42);
   Graph_grPythia_115_15032->GetYaxis()->SetTitleSize(0.05);
   Graph_grPythia_115_15032->GetYaxis()->SetTitleFont(42);
   Graph_grPythia_115_15032->GetZaxis()->SetLabelFont(42);
   Graph_grPythia_115_15032->GetZaxis()->SetTitleOffset(1);
   Graph_grPythia_115_15032->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grPythia_115_15032);
   
   multigraph->Add(graph,"P");
   multigraph->Draw("AP");
   multigraph->GetXaxis()->SetLimits(-3.063, 3.141);
   multigraph->GetXaxis()->SetTitle("#eta_{dijet}");
   multigraph->GetXaxis()->SetLabelFont(42);
   multigraph->GetXaxis()->SetTitleSize(0.05);
   multigraph->GetXaxis()->SetTitleOffset(1);
   multigraph->GetXaxis()->SetTitleFont(42);
   multigraph->GetYaxis()->SetTitle("1/N_{dijet} d#sigma/d#eta_{dijet}");
   multigraph->GetYaxis()->SetLabelFont(42);
   multigraph->GetYaxis()->SetTitleSize(0.05);
   multigraph->GetYaxis()->SetTitleFont(42);
      tex = new TLatex(0.18,0.87,"115 < p_{T}^{ave} < 150 GeV/c");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
   cPub_4__13->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_5
   TPad *cPub_5__14 = new TPad("cPub_5", "cPub_5",0.81,0.51,0.99,0.99);
   cPub_5__14->Draw();
   cPub_5__14->cd();
   cPub_5__14->Range(-4.170857,-0.1094276,3.214857,0.4763163);
   cPub_5__14->SetFillColor(0);
   cPub_5__14->SetBorderMode(0);
   cPub_5__14->SetBorderSize(2);
   cPub_5__14->SetLeftMargin(0.15);
   cPub_5__14->SetRightMargin(0.01);
   cPub_5__14->SetTopMargin(0.04);
   cPub_5__14->SetBottomMargin(0.15);
   cPub_5__14->SetFrameBorderMode(0);
   cPub_5__14->SetFrameBorderMode(0);
   
   multigraph = new TMultiGraph();
   multigraph->SetName("mgComp_150_400");
   multigraph->SetTitle("");
   
   Double_t grMy_150_400_fx33[21] = { -2.781, -2.499, -2.217, -1.935, -1.653, -1.371, -1.089, -0.807, -0.525, -0.243, 0.039, 0.321, 0.603, 0.885, 1.167, 1.449, 1.731,
   2.013, 2.295, 2.577, 2.859 };
   Double_t grMy_150_400_fy33[21] = { 0, 0, 5.643297e-05, 0.00210784, 0.01575176, 0.05213635, 0.1132606, 0.1881816, 0.2718383, 0.3446065, 0.3948722, 0.4246054, 0.4234696, 0.3896057, 0.3398371, 0.2600791, 0.1800553,
   0.1010657, 0.04376179, 0.01083343, 0.001055308 };
   graph = new TGraph(21,grMy_150_400_fx33,grMy_150_400_fy33);
   graph->SetName("grMy_150_400");
   graph->SetTitle("rep3020_pt1pt2_150_400_mu05_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(4);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(4);
   graph->SetMarkerStyle(24);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_grMy_150_40033 = new TH1F("Graph_grMy_150_40033","rep3020_pt1pt2_150_400_mu05_5020gev.txt",100,-3.345,3.423);
   Graph_grMy_150_40033->SetMinimum(0);
   Graph_grMy_150_40033->SetMaximum(2.873212);
   Graph_grMy_150_40033->SetDirectory(nullptr);
   Graph_grMy_150_40033->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grMy_150_40033->SetLineColor(ci);
   Graph_grMy_150_40033->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grMy_150_40033->GetXaxis()->SetLabelFont(42);
   Graph_grMy_150_40033->GetXaxis()->SetTitleSize(0.05);
   Graph_grMy_150_40033->GetXaxis()->SetTitleOffset(1);
   Graph_grMy_150_40033->GetXaxis()->SetTitleFont(42);
   Graph_grMy_150_40033->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grMy_150_40033->GetYaxis()->SetLabelFont(42);
   Graph_grMy_150_40033->GetYaxis()->SetTitleSize(0.05);
   Graph_grMy_150_40033->GetYaxis()->SetTitleFont(42);
   Graph_grMy_150_40033->GetZaxis()->SetLabelFont(42);
   Graph_grMy_150_40033->GetZaxis()->SetTitleOffset(1);
   Graph_grMy_150_40033->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grMy_150_40033);
   
   multigraph->Add(graph,"AP");
   
   Double_t grPub_150_400_fx34[16] = { -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085, 1.7325, 2.155, 2.71835 };
   Double_t grPub_150_400_fy34[16] = { 0.001266443, 0.01181667, 0.04391393, 0.1053819, 0.1870417, 0.2714239, 0.3484368, 0.4027043, 0.4313205, 0.430086, 0.4014251, 0.3462938, 0.2681027, 0.1808697, 0.06846298, 0.004653462 };
   graph = new TGraph(16,grPub_150_400_fx34,grPub_150_400_fy34);
   graph->SetName("grPub_150_400");
   graph->SetTitle("pub_150_400_5020gev.txt");
   graph->SetFillStyle(1000);
   graph->SetLineColor(2);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(2);
   graph->SetMarkerStyle(20);
   graph->SetMarkerSize(1.2);
   
   TH1F *Graph_grPub_150_40034 = new TH1F("Graph_grPub_150_40034","pub_150_400_5020gev.txt",100,-2.3939,3.1831);
   Graph_grPub_150_40034->SetMinimum(0.07063189);
   Graph_grPub_150_40034->SetMaximum(29.39338);
   Graph_grPub_150_40034->SetDirectory(nullptr);
   Graph_grPub_150_40034->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grPub_150_40034->SetLineColor(ci);
   Graph_grPub_150_40034->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grPub_150_40034->GetXaxis()->SetLabelFont(42);
   Graph_grPub_150_40034->GetXaxis()->SetTitleSize(0.05);
   Graph_grPub_150_40034->GetXaxis()->SetTitleOffset(1);
   Graph_grPub_150_40034->GetXaxis()->SetTitleFont(42);
   Graph_grPub_150_40034->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grPub_150_40034->GetYaxis()->SetLabelFont(42);
   Graph_grPub_150_40034->GetYaxis()->SetTitleSize(0.05);
   Graph_grPub_150_40034->GetYaxis()->SetTitleFont(42);
   Graph_grPub_150_40034->GetZaxis()->SetLabelFont(42);
   Graph_grPub_150_40034->GetZaxis()->SetTitleOffset(1);
   Graph_grPub_150_40034->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grPub_150_40034);
   
   multigraph->Add(graph,"AP");
   
   Double_t grPythia_150_400_fx35[21] = { -2.781, -2.499, -2.217, -1.935, -1.653, -1.371, -1.089, -0.807, -0.525, -0.243, 0.039, 0.321, 0.603, 0.885, 1.167, 1.449, 1.731,
   2.013, 2.295, 2.577, 2.859 };
   Double_t grPythia_150_400_fy35[21] = { 0, 0, 0.0002889694, 0.001490276, 0.01282663, 0.04357172, 0.1053566, 0.1788678, 0.2658266, 0.3457194, 0.4062705, 0.4321838, 0.4347126, 0.4074904, 0.3397524, 0.2608591, 0.1732668,
   0.09605191, 0.03714248, 0.008177509, 0.0003953747 };
   graph = new TGraph(21,grPythia_150_400_fx35,grPythia_150_400_fy35);
   graph->SetName("grPythia_150_400");
   graph->SetTitle("PYTHIA dijet #eta");
   graph->SetLineColor(15);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(15);
   graph->SetMarkerStyle(41);
   graph->SetMarkerSize(1.3);
   
   TH1F *Graph_grPythia_150_40035 = new TH1F("Graph_grPythia_150_40035","PYTHIA dijet #eta",100,-3.345,3.423);
   Graph_grPythia_150_40035->SetMinimum(0);
   Graph_grPythia_150_40035->SetMaximum(0.1595005);
   Graph_grPythia_150_40035->SetDirectory(nullptr);
   Graph_grPythia_150_40035->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grPythia_150_40035->SetLineColor(ci);
   Graph_grPythia_150_40035->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grPythia_150_40035->GetXaxis()->SetLabelFont(42);
   Graph_grPythia_150_40035->GetXaxis()->SetTitleSize(0.05);
   Graph_grPythia_150_40035->GetXaxis()->SetTitleOffset(1);
   Graph_grPythia_150_40035->GetXaxis()->SetTitleFont(42);
   Graph_grPythia_150_40035->GetYaxis()->SetTitle("1/N_{dijet} dN/d#eta_{dijet}");
   Graph_grPythia_150_40035->GetYaxis()->SetLabelFont(42);
   Graph_grPythia_150_40035->GetYaxis()->SetTitleSize(0.05);
   Graph_grPythia_150_40035->GetYaxis()->SetTitleFont(42);
   Graph_grPythia_150_40035->GetZaxis()->SetLabelFont(42);
   Graph_grPythia_150_40035->GetZaxis()->SetTitleOffset(1);
   Graph_grPythia_150_40035->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grPythia_150_40035);
   
   multigraph->Add(graph,"P");
   multigraph->Draw("AP");
   multigraph->GetXaxis()->SetLimits(-3.063, 3.141);
   multigraph->GetXaxis()->SetTitle("#eta_{dijet}");
   multigraph->GetXaxis()->SetLabelFont(42);
   multigraph->GetXaxis()->SetTitleSize(0.05);
   multigraph->GetXaxis()->SetTitleOffset(1);
   multigraph->GetXaxis()->SetTitleFont(42);
   multigraph->GetYaxis()->SetTitle("1/N_{dijet} d#sigma/d#eta_{dijet}");
   multigraph->GetYaxis()->SetLabelFont(42);
   multigraph->GetYaxis()->SetTitleSize(0.05);
   multigraph->GetYaxis()->SetTitleFont(42);
      tex = new TLatex(0.18,0.87,"150 < p_{T}^{ave} < 400 GeV/c");
   tex->SetNDC();
   tex->SetTextFont(42);
   tex->SetTextSize(0.04);
   tex->SetLineWidth(2);
   tex->Draw();
   cPub_5__14->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_6
   TPad *cPub_6__15 = new TPad("cPub_6", "cPub_6",0.01,0.01,0.19,0.49);
   cPub_6__15->Draw();
   cPub_6__15->cd();
   cPub_6__15->Range(-3.046481,0.7259259,1.878661,1.219753);
   cPub_6__15->SetFillColor(0);
   cPub_6__15->SetBorderMode(0);
   cPub_6__15->SetBorderSize(2);
   cPub_6__15->SetLeftMargin(0.15);
   cPub_6__15->SetRightMargin(0.01);
   cPub_6__15->SetTopMargin(0.04);
   cPub_6__15->SetBottomMargin(0.15);
   cPub_6__15->SetFrameBorderMode(0);
   cPub_6__15->SetFrameBorderMode(0);
   
   Double_t grRat_55_75_fx36[13] = { -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085 };
   Double_t grRat_55_75_fy36[13] = { 1.047233, 1.051206, 0.985536, 1.117963, 1.04958, 1.011561, 1.001095, 0.9748577, 0.9697575, 1.001233, 1.015608, 1.051661, 1.091104 };
   graph = new TGraph(13,grRat_55_75_fx36,grRat_55_75_fy36);
   graph->SetName("grRat_55_75");
   graph->SetTitle("");
   graph->SetFillStyle(1000);
   graph->SetLineColor(6);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(6);
   graph->SetMarkerStyle(35);
   graph->SetMarkerSize(1.3);
   
   TH1F *Graph_grRat_55_7536 = new TH1F("Graph_grRat_55_7536","",100,-2.26715,1.78885);
   Graph_grRat_55_7536->SetMinimum(0.8);
   Graph_grRat_55_7536->SetMaximum(1.2);
   Graph_grRat_55_7536->SetDirectory(nullptr);
   Graph_grRat_55_7536->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grRat_55_7536->SetLineColor(ci);
   Graph_grRat_55_7536->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grRat_55_7536->GetXaxis()->SetRange(0,101);
   Graph_grRat_55_7536->GetXaxis()->SetLabelFont(42);
   Graph_grRat_55_7536->GetXaxis()->SetTitleSize(0.05);
   Graph_grRat_55_7536->GetXaxis()->SetTitleOffset(1);
   Graph_grRat_55_7536->GetXaxis()->SetTitleFont(42);
   Graph_grRat_55_7536->GetYaxis()->SetTitle("Published / My");
   Graph_grRat_55_7536->GetYaxis()->SetLabelFont(42);
   Graph_grRat_55_7536->GetYaxis()->SetTitleSize(0.05);
   Graph_grRat_55_7536->GetYaxis()->SetTitleFont(42);
   Graph_grRat_55_7536->GetZaxis()->SetLabelFont(42);
   Graph_grRat_55_7536->GetZaxis()->SetTitleOffset(1);
   Graph_grRat_55_7536->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grRat_55_7536);
   
   graph->Draw("ap");
   TLine *line = new TLine(-2.26715,1,1.78885,1);
   line->SetLineColor(8);
   line->SetLineStyle(2);
   line->SetLineWidth(2);
   line->Draw();
   cPub_6__15->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_7
   TPad *cPub_7__16 = new TPad("cPub_7", "cPub_7",0.21,0.01,0.39,0.49);
   cPub_7__16->Draw();
   cPub_7__16->cd();
   cPub_7__16->Range(-3.046481,0.7259259,1.878661,1.219753);
   cPub_7__16->SetFillColor(0);
   cPub_7__16->SetBorderMode(0);
   cPub_7__16->SetBorderSize(2);
   cPub_7__16->SetLeftMargin(0.15);
   cPub_7__16->SetRightMargin(0.01);
   cPub_7__16->SetTopMargin(0.04);
   cPub_7__16->SetBottomMargin(0.15);
   cPub_7__16->SetFrameBorderMode(0);
   cPub_7__16->SetFrameBorderMode(0);
   
   Double_t grRat_75_95_fx37[13] = { -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085 };
   Double_t grRat_75_95_fy37[13] = { 0.9386329, 1.050847, 0.9717118, 1.149648, 1.057957, 1.05445, 1.01373, 1.031257, 1.025469, 1.020891, 1.036252, 1.080042, 1.129322 };
   graph = new TGraph(13,grRat_75_95_fx37,grRat_75_95_fy37);
   graph->SetName("grRat_75_95");
   graph->SetTitle("");
   graph->SetFillStyle(1000);
   graph->SetLineColor(6);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(6);
   graph->SetMarkerStyle(35);
   graph->SetMarkerSize(1.3);
   
   TH1F *Graph_grRat_75_9537 = new TH1F("Graph_grRat_75_9537","",100,-2.26715,1.78885);
   Graph_grRat_75_9537->SetMinimum(0.8);
   Graph_grRat_75_9537->SetMaximum(1.2);
   Graph_grRat_75_9537->SetDirectory(nullptr);
   Graph_grRat_75_9537->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grRat_75_9537->SetLineColor(ci);
   Graph_grRat_75_9537->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grRat_75_9537->GetXaxis()->SetRange(0,101);
   Graph_grRat_75_9537->GetXaxis()->SetLabelFont(42);
   Graph_grRat_75_9537->GetXaxis()->SetTitleSize(0.05);
   Graph_grRat_75_9537->GetXaxis()->SetTitleOffset(1);
   Graph_grRat_75_9537->GetXaxis()->SetTitleFont(42);
   Graph_grRat_75_9537->GetYaxis()->SetTitle("Published / My");
   Graph_grRat_75_9537->GetYaxis()->SetLabelFont(42);
   Graph_grRat_75_9537->GetYaxis()->SetTitleSize(0.05);
   Graph_grRat_75_9537->GetYaxis()->SetTitleFont(42);
   Graph_grRat_75_9537->GetZaxis()->SetLabelFont(42);
   Graph_grRat_75_9537->GetZaxis()->SetTitleOffset(1);
   Graph_grRat_75_9537->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grRat_75_9537);
   
   graph->Draw("ap");
   line = new TLine(-2.26715,1,1.78885,1);
   line->SetLineColor(8);
   line->SetLineStyle(2);
   line->SetLineWidth(2);
   line->Draw();
   cPub_7__16->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_8
   TPad *cPub_8__17 = new TPad("cPub_8", "cPub_8",0.41,0.01,0.59,0.49);
   cPub_8__17->Draw();
   cPub_8__17->cd();
   cPub_8__17->Range(-3.046481,0.7259259,1.878661,1.219753);
   cPub_8__17->SetFillColor(0);
   cPub_8__17->SetBorderMode(0);
   cPub_8__17->SetBorderSize(2);
   cPub_8__17->SetLeftMargin(0.15);
   cPub_8__17->SetRightMargin(0.01);
   cPub_8__17->SetTopMargin(0.04);
   cPub_8__17->SetBottomMargin(0.15);
   cPub_8__17->SetFrameBorderMode(0);
   cPub_8__17->SetFrameBorderMode(0);
   
   Double_t grRat_95_115_fx38[13] = { -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085 };
   Double_t grRat_95_115_fy38[13] = { 0.8273724, 0.9906267, 1.156578, 1.041849, 1.044855, 1.014405, 1.029099, 0.9875386, 1.007801, 1.016107, 1.006612, 1.045533, 1.087264 };
   graph = new TGraph(13,grRat_95_115_fx38,grRat_95_115_fy38);
   graph->SetName("grRat_95_115");
   graph->SetTitle("");
   graph->SetFillStyle(1000);
   graph->SetLineColor(6);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(6);
   graph->SetMarkerStyle(35);
   graph->SetMarkerSize(1.3);
   
   TH1F *Graph_grRat_95_11538 = new TH1F("Graph_grRat_95_11538","",100,-2.26715,1.78885);
   Graph_grRat_95_11538->SetMinimum(0.8);
   Graph_grRat_95_11538->SetMaximum(1.2);
   Graph_grRat_95_11538->SetDirectory(nullptr);
   Graph_grRat_95_11538->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grRat_95_11538->SetLineColor(ci);
   Graph_grRat_95_11538->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grRat_95_11538->GetXaxis()->SetRange(0,101);
   Graph_grRat_95_11538->GetXaxis()->SetLabelFont(42);
   Graph_grRat_95_11538->GetXaxis()->SetTitleSize(0.05);
   Graph_grRat_95_11538->GetXaxis()->SetTitleOffset(1);
   Graph_grRat_95_11538->GetXaxis()->SetTitleFont(42);
   Graph_grRat_95_11538->GetYaxis()->SetTitle("Published / My");
   Graph_grRat_95_11538->GetYaxis()->SetLabelFont(42);
   Graph_grRat_95_11538->GetYaxis()->SetTitleSize(0.05);
   Graph_grRat_95_11538->GetYaxis()->SetTitleFont(42);
   Graph_grRat_95_11538->GetZaxis()->SetLabelFont(42);
   Graph_grRat_95_11538->GetZaxis()->SetTitleOffset(1);
   Graph_grRat_95_11538->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grRat_95_11538);
   
   graph->Draw("ap");
   line = new TLine(-2.26715,1,1.78885,1);
   line->SetLineColor(8);
   line->SetLineStyle(2);
   line->SetLineWidth(2);
   line->Draw();
   cPub_8__17->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_9
   TPad *cPub_9__18 = new TPad("cPub_9", "cPub_9",0.61,0.01,0.79,0.49);
   cPub_9__18->Draw();
   cPub_9__18->cd();
   cPub_9__18->Range(-3.046481,0.7259259,1.878661,1.219753);
   cPub_9__18->SetFillColor(0);
   cPub_9__18->SetBorderMode(0);
   cPub_9__18->SetBorderSize(2);
   cPub_9__18->SetLeftMargin(0.15);
   cPub_9__18->SetRightMargin(0.01);
   cPub_9__18->SetTopMargin(0.04);
   cPub_9__18->SetBottomMargin(0.15);
   cPub_9__18->SetFrameBorderMode(0);
   cPub_9__18->SetFrameBorderMode(0);
   
   Double_t grRat_115_150_fx39[13] = { -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085 };
   Double_t grRat_115_150_fy39[13] = { 0.7615275, 0.878664, 0.9697749, 0.9894314, 1.024194, 1.030935, 1.021071, 1.009552, 0.9994474, 0.9990631, 1.010486, 1.033321, 1.063924 };
   graph = new TGraph(13,grRat_115_150_fx39,grRat_115_150_fy39);
   graph->SetName("grRat_115_150");
   graph->SetTitle("");
   graph->SetFillStyle(1000);
   graph->SetLineColor(6);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(6);
   graph->SetMarkerStyle(35);
   graph->SetMarkerSize(1.3);
   
   TH1F *Graph_grRat_115_15039 = new TH1F("Graph_grRat_115_15039","",100,-2.26715,1.78885);
   Graph_grRat_115_15039->SetMinimum(0.8);
   Graph_grRat_115_15039->SetMaximum(1.2);
   Graph_grRat_115_15039->SetDirectory(nullptr);
   Graph_grRat_115_15039->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grRat_115_15039->SetLineColor(ci);
   Graph_grRat_115_15039->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grRat_115_15039->GetXaxis()->SetRange(0,101);
   Graph_grRat_115_15039->GetXaxis()->SetLabelFont(42);
   Graph_grRat_115_15039->GetXaxis()->SetTitleSize(0.05);
   Graph_grRat_115_15039->GetXaxis()->SetTitleOffset(1);
   Graph_grRat_115_15039->GetXaxis()->SetTitleFont(42);
   Graph_grRat_115_15039->GetYaxis()->SetTitle("Published / My");
   Graph_grRat_115_15039->GetYaxis()->SetLabelFont(42);
   Graph_grRat_115_15039->GetYaxis()->SetTitleSize(0.05);
   Graph_grRat_115_15039->GetYaxis()->SetTitleFont(42);
   Graph_grRat_115_15039->GetZaxis()->SetLabelFont(42);
   Graph_grRat_115_15039->GetZaxis()->SetTitleOffset(1);
   Graph_grRat_115_15039->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grRat_115_15039);
   
   graph->Draw("ap");
   line = new TLine(-2.26715,1,1.78885,1);
   line->SetLineColor(8);
   line->SetLineStyle(2);
   line->SetLineWidth(2);
   line->Draw();
   cPub_9__18->Modified();
   cPub->cd();
  
// ------------>Primitives in pad: cPub_10
   TPad *cPub_10__19 = new TPad("cPub_10", "cPub_10",0.81,0.01,0.99,0.49);
   cPub_10__19->Draw();
   cPub_10__19->cd();
   cPub_10__19->Range(-3.046481,0.7259259,1.878661,1.219753);
   cPub_10__19->SetFillColor(0);
   cPub_10__19->SetBorderMode(0);
   cPub_10__19->SetBorderSize(2);
   cPub_10__19->SetLeftMargin(0.15);
   cPub_10__19->SetRightMargin(0.01);
   cPub_10__19->SetTopMargin(0.04);
   cPub_10__19->SetBottomMargin(0.15);
   cPub_10__19->SetFrameBorderMode(0);
   cPub_10__19->SetFrameBorderMode(0);
   
   Double_t grRat_150_400_fx40[13] = { -1.92915, -1.6475, -1.36585, -1.08415, -0.8025, -0.52085, -0.23915, 0.0425, 0.32415, 0.60585, 0.8875, 1.16915, 1.45085 };
   Double_t grRat_150_400_fy40[13] = { 0.600825, 0.7501811, 0.8422901, 0.9304369, 0.9939423, 0.9984756, 1.011115, 1.019834, 1.015815, 1.015624, 1.030337, 1.018999, 1.030851 };
   graph = new TGraph(13,grRat_150_400_fx40,grRat_150_400_fy40);
   graph->SetName("grRat_150_400");
   graph->SetTitle("");
   graph->SetFillStyle(1000);
   graph->SetLineColor(6);
   graph->SetLineWidth(2);
   graph->SetMarkerColor(6);
   graph->SetMarkerStyle(35);
   graph->SetMarkerSize(1.3);
   
   TH1F *Graph_grRat_150_40040 = new TH1F("Graph_grRat_150_40040","",100,-2.26715,1.78885);
   Graph_grRat_150_40040->SetMinimum(0.8);
   Graph_grRat_150_40040->SetMaximum(1.2);
   Graph_grRat_150_40040->SetDirectory(nullptr);
   Graph_grRat_150_40040->SetStats(0);

   ci = TColor::GetColor("#000099");
   Graph_grRat_150_40040->SetLineColor(ci);
   Graph_grRat_150_40040->GetXaxis()->SetTitle("#eta_{dijet}");
   Graph_grRat_150_40040->GetXaxis()->SetRange(0,101);
   Graph_grRat_150_40040->GetXaxis()->SetLabelFont(42);
   Graph_grRat_150_40040->GetXaxis()->SetTitleSize(0.05);
   Graph_grRat_150_40040->GetXaxis()->SetTitleOffset(1);
   Graph_grRat_150_40040->GetXaxis()->SetTitleFont(42);
   Graph_grRat_150_40040->GetYaxis()->SetTitle("Published / My");
   Graph_grRat_150_40040->GetYaxis()->SetLabelFont(42);
   Graph_grRat_150_40040->GetYaxis()->SetTitleSize(0.05);
   Graph_grRat_150_40040->GetYaxis()->SetTitleFont(42);
   Graph_grRat_150_40040->GetZaxis()->SetLabelFont(42);
   Graph_grRat_150_40040->GetZaxis()->SetTitleOffset(1);
   Graph_grRat_150_40040->GetZaxis()->SetTitleFont(42);
   graph->SetHistogram(Graph_grRat_150_40040);
   
   graph->Draw("ap");
   line = new TLine(-2.26715,1,1.78885,1);
   line->SetLineColor(8);
   line->SetLineStyle(2);
   line->SetLineWidth(2);
   line->Draw();
   cPub_10__19->Modified();
   cPub->cd();
   cPub->Modified();
   cPub->SetSelected(cPub);
   cPub->ToggleToolBar();
}
